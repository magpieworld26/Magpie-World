---
name: story-continuation
description: >
  Drives the recursive AI story generation engine for an interactive choice-based reading app. Use this skill whenever the user wants to: (1) START a new story session by providing a story context, initial text, and first choices — the skill collects these inputs and runs the first continuation turn; (2) CONTINUE a story by making a choice from the presented options; (3) TEST or evaluate a story generation prompt. This skill is the backbone of the Netflix-for-stories app. Trigger it whenever the user pastes a story context, says "start story", "I choose option X", "continue the story", "let's test this storyline", or provides a block of text that looks like a story context or opening scene.
---

# Story Continuation Skill

This skill does two things:
1. **Intake** — Collects story context, initial text, and first choices from the user to initialise a story session
2. **Continue** — Generates the next scene and new choices after the reader picks an option, maintaining a live story state across turns

---

## Step 0: Determine Mode

Read the conversation and decide which mode applies:

| Mode | Signal |
|---|---|
| **INTAKE** | User is pasting a story context + initial text + first choices for the first time, or says "start story", "new story", "here is my storyline" |
| **CONTINUE** | User has picked a choice (e.g. "I choose A", "option B", "let's go with C") and a story session is already in progress in this conversation |

If it is ambiguous, ask: "Are you starting a new story or continuing one?"

---

## MODE: INTAKE

### What to collect

Ask the user to provide all three of the following. If any are missing from their message, ask for them before proceeding:

1. **Story context** — The "bible": world setting, atmosphere, key characters (names, personalities, relationships), central themes, tone, genre, and any rules or lore the story world follows. This is never shown to the reader. It is the immutable canon the AI uses for all generation.

2. **Initial text** — The opening scene the reader sees. Should be 900–1200 words, written in second person ("you"), richly atmospheric, and end at a natural decision point.

3. **First choices** — The 3–4 choices the reader sees after the initial text. Format: one choice per line, labelled A / B / C / (D).

### Once all three are provided

1. Acknowledge receipt clearly:
   > "Got it. Here is your story session initialised."

2. Display a **Story Session Block** (see format below).

3. Display the **initial text** exactly as provided, formatted cleanly.

4. Display the **first choices** as a numbered/lettered list, ready for the reader to pick.

5. Initialise the Story State (see below) and display it collapsed or as a footnote so the user can see it is being tracked.

6. Tell the user: "Pick a choice (A, B, C…) and I'll generate the next scene."

---

## MODE: CONTINUE

This is the core loop. It runs every time the reader picks a choice.

### Inputs you must have in context

- The original **story context** (from INTAKE or earlier in the conversation)
- The current **story state** (updated after every turn)
- The **last 1–2 scenes** of actual prose (for voice continuity)
- The **choice just made** by the reader

If any of these are missing, ask the user to re-paste them before proceeding.

---

### The 4-Layer Prompt System

When generating a continuation, your output must be driven by four layers working together. Do not skip any layer.

**Layer 1 — Story Bible (immutable)**
The original story context. Treat it as absolute canon. Never contradict it. Reference it for character behaviour, world rules, and tone.

**Layer 2 — Story State (living memory)**
A structured summary updated after every turn. Never use a raw transcript — use the structured state. See Story State Format below.

**Layer 3 — Continuation Directive**
The core writing instruction (full text in `references/continuation-directive.md`). Always apply it.

**Layer 4 — Output Format**
Produce output in the exact Scene Output Format below.

---

### Story State Format

Maintain and update this after every turn. Display it to the user (collapsed if preferred) so they can verify continuity:

```
STORY STATE
───────────
Turn: [number]
Arc position: [opening → establishing → deepening → converging → climax → resolution]
Choices made:
  - Turn 1: "[choice label]" → [one-line consequence note]
  - Turn 2: ...
Relationship states:
  - [Character name]: [current dynamic in ~10 words]
World state changes:
  - [what has changed due to reader choices]
Planted threads:
  - [details/hints dropped that should pay off later]
Active tensions:
  - [unresolved pressures driving the reader forward]
```

**Arc position guide:**
- Turns 1–2: `opening` / `establishing`
- Turns 3–4: `deepening`
- Turns 5–6: `converging`
- Turns 7+: `climax` / `resolution`

---

### Scene Output Format

After generating the continuation, output in this order:

---

**[Turn N · Arc: [position]]**

[Scene text — see Continuation Directive for architecture rules]

---

**Choose your path:**

**A. [You — concrete action in present tense]**
*[One sentence: what this path offers or risks]*

**B. [You — concrete action in present tense]**
*[One sentence: what this path offers or risks]*

**C. [You — concrete action in present tense]**
*[One sentence: what this path offers or risks]*

---

*[Updated story state block]*

---

### Scene Architecture (600–900 words)

Structure every continuation scene in three beats:

**Beat 1 — Immediate consequence (open, no recap, 2–3 sentences)**
Show the choice in motion. The reader just acted — show what happens in the next breath. Never summarise the previous scene.

**Beat 2 — Consequence unfolds (200–300 words)**
The direct result of the choice plays out. Include at least one **unexpected element** — something the reader didn't fully anticipate. Show the world responding specifically to *this* choice, not a generic version of it.

**Beat 3 — New ground (200–300 words)**
The story moves forward. New information surfaces, a character dynamic shifts, or the setting opens up. By the end of this beat the reader should feel the story has genuinely advanced, not just continued.

**Deceleration (final 2–3 paragraphs)**
Slow the pacing slightly as you approach the new decision point. Let the reader feel the weight of what's coming. The decision point should feel inevitable — the whole scene led here.

---

### Choice Generation Rules

Generate exactly 3 choices per turn (4 only if the situation genuinely demands it).

- Each choice must be **meaningfully distinct** — different values, different risks, different types of engagement with the world
- No choice should be obviously superior. Each must offer something the others don't.
- At least one choice should feel **unexpected or surprising** — an option the reader might not have anticipated
- Choices must reference **specific details** from the current scene, not generic actions
- Format: "You [action verb]..." — second person, present tense, concrete physical or social action
- Follow each choice with one sentence of subtext: what the reader would gain, risk, or experience by choosing it

**Avoid:**
- Choices that are the same action with different adjectives ("You run cautiously" vs "You run boldly")
- A clearly safe choice, a clearly risky choice, and a clearly neutral choice (too formulaic)
- Choices that ignore what just happened in the scene

---

### Continuity Rules

These are non-negotiable:

1. **Every named character** must behave consistently with their established personality and their current relationship state with the reader
2. **World-state changes are permanent.** If a door was locked two turns ago, it is still locked unless a choice explicitly changed that
3. **Planted threads must eventually pay off.** Track them in the story state and weave them back in at the `deepening` or `converging` arc positions
4. **The reader's choices must echo forward.** A choice made in Turn 2 should still be visible in the world at Turn 5 — in how a character speaks to you, what is available, what is closed off
5. **Voice consistency.** Match the genre tone, sentence rhythm, and vocabulary level established in the initial text throughout all turns

---

### Pacing by Arc Position

| Arc position | What should happen | Choice style |
|---|---|---|
| `opening` | Ground the reader, establish world feel | Direction-based, low stakes |
| `establishing` | Introduce key characters and tensions | Values-based, beginning to diverge |
| `deepening` | Complicate, reveal, deepen relationships | Higher stakes, more morally textured |
| `converging` | Threads start to collide, pressure rises | Dilemma-based, real trade-offs |
| `climax` | Peak intensity, major consequences | Hard choices, no clean options |
| `resolution` | Loops close, consequences land | Choices resolve rather than open |

---

## Quality Checklist (run mentally before every output)

- [ ] Choice made is immediately visible in the opening of the scene
- [ ] At least one unexpected element in the consequence
- [ ] Story state is updated and accurate
- [ ] All named characters behave consistently with their established state
- [ ] World-state changes from prior turns are still reflected
- [ ] Arc position is correct for the turn number
- [ ] Pacing matches arc position
- [ ] All 3 choices are genuinely distinct
- [ ] No choice is obviously superior
- [ ] At least one choice is surprising
- [ ] Choices reference specific details from this scene
- [ ] Voice and tone match the story bible and initial text
- [ ] Scene is 600–900 words

---

## Reference files

Read `references/continuation-directive.md` before generating any scene continuation. It contains the full prose-level writing instruction for story generation quality.
